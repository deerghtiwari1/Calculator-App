package com.example.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    EditText p1,p2,p3;
    Button b1,b2,b3,b4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        p1=findViewById(R.id.n1);
        p2=findViewById(R.id.n2);
        b1=findViewById(R.id.bt1);
        b2=findViewById(R.id.bt2);
        b3=findViewById(R.id.bt3);
        b4=findViewById(R.id.bt4);
    }

    public void addition(View obj){

        int n1=Integer.parseInt(p1.getText().toString());
        int n2=Integer.parseInt(p2.getText().toString());
        int n3=n1+n2;
        p3.setText(String.valueOf(n3));
        cln();


    }

    public void subtraction(View obj){

        int n1=Integer.parseInt(p1.getText().toString());
        int n2=Integer.parseInt(p2.getText().toString());
        int n3=n1-n2;
        p3.setText(String.valueOf(n3));
        cln();


    }
    public void multiplication(View obj){

        int n1=Integer.parseInt(p1.getText().toString());
        int n2=Integer.parseInt(p2.getText().toString());
        int n3=n1*n2;
        p3.setText(String.valueOf(n3));
        cln();


    }

    public void divison(View obj){

        int n1=Integer.parseInt(p1.getText().toString());
        int n2=Integer.parseInt(p2.getText().toString());
        int n3=n1/n2;
        p3.setText(String.valueOf(n3));
        cln();


    }

    public void percentage(View obj){

        int n1=Integer.parseInt(p1.getText().toString());
        int n2=Integer.parseInt(p2.getText().toString());
        float n3=n1*n2/100;
        p3.setText(String.valueOf(n3));
        cln();


    }

    public void cln(){
        p1.setText(null);
        p2.setText(null);

    }
}